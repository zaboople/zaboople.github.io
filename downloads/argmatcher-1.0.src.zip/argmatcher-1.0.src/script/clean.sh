cd $(dirname $0)/..
ant clean
