cd /c/troy/dev/textedit
ant config.test compile

