package org.tmotte.klonk.config.msg;

/** Oh no, another one like Getter Setter. Doer. Oh no. */
public interface Doer {
  public void doIt();
}