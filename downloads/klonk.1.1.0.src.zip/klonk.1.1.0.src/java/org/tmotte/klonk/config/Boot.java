package org.tmotte.klonk.config;

public class Boot {

  public static void main(String[] args) {
    BootContext.bootApplication(args);
  }
  
}