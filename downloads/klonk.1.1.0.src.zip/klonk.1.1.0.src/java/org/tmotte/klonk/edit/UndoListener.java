package org.tmotte.klonk.edit;
public interface UndoListener {
  public void happened(UndoEvent mta);
}