package org.tmotte.klonk.windows.popup;
public interface LineDelimiterListener {
  public void setDefault(String delimiter);
  public void setThis(String delimiter);
}