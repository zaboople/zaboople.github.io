find . -name '*.java' | xargs egrep "$@"

